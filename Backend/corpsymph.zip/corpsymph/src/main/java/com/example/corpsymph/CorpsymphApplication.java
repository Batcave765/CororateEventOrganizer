package com.example.corpsymph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorpsymphApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorpsymphApplication.class, args);
	}

}
